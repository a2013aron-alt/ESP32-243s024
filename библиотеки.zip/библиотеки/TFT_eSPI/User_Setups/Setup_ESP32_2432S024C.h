/*
// Настройки для ESP32-2432S024C с ILI9341 и XPT2046
#define ILI9341_DRIVER
//#define ST7789_DRIVER

// Пины для TFT-дисплея
#define TFT_MISO  -1
//#define TFT_MOSI  23
//#define TFT_SCLK  18
//#define TFT_CS    15
//#define TFT_DC    2
#define TFT_MOSI 23
#define TFT_SCLK 18
#define TFT_CS   5
#define TFT_DC   27//
#define TFT_RST   -1   // Reset подключён к общему RESET платы
#define TFT_BL 27

// Пины для сенсорного экрана
#define TOUCH_CS  5
#define TOUCH_IRQ 27   // Опционально, для прерываний

// Частоты SPI
#define SPI_FREQUENCY        20000000
#define SPI_TOUCH_FREQUENCY  2500000

// Подсветка
#define TFT_BACKLIGHT_ON HIGH

// Настройки для ESP32-2432S024C с ILI9341 и CST820 capacitive touch
#define ILI9341_DRIVER
//#define ST7789_DRIVER

// Пины для TFT-дисплея
#define TFT_MISO  12
#define TFT_MOSI  13
#define TFT_SCLK  14
#define TFT_CS    15
#define TFT_DC     2
#define TFT_RST   -1   // Reset подключён к общему RESET платы
#define TFT_BL    27   // Подсветка (подтверждено, работает)

// Частоты SPI
#define SPI_FREQUENCY  10000000  // 10 МГц для стабильности

// Подсветка
#define TFT_BACKLIGHT_ON HIGH


// Настройки для ESP32-2432S024C с ILI9341
#define ILI9341_DRIVER

// Пины для TFT-дисплея
#define TFT_MISO  12
#define TFT_MOSI  13
#define TFT_SCLK  14
#define TFT_CS    15
#define TFT_DC     2
#define TFT_RST   33   // Пробуем явный RESET вместо -1
#define TFT_BL    27   // Подсветка (подтверждено, работает)

// Частоты SPI
#define SPI_FREQUENCY 20000000

// Подсветка
#define TFT_BACKLIGHT_ON HIGH


// Настройки для ESP32-2432S024C с ILI9341
#define ILI9341_DRIVER

// Пины для TFT-дисплея
#define TFT_MISO  12
#define TFT_MOSI  13
#define TFT_SCLK  14
#define TFT_CS    15
#define TFT_DC     2
#define TFT_RST   33   // Явный RESET
#define TFT_BL    27   // Подсветка (подтверждено, работает)

// Частоты SPI
#define SPI_FREQUENCY  20000000  // 20
// Подсветка
#define TFT_BACKLIGHT_ON HIGH
//шрифты опционально
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT
//сенсорит
#define TOUCH_CS -1  // Не используется, так как CST816S работает через I2C
#define CST816S_TOUCH  // Включить поддержку CST816S
#define I2C_SDA 21     // Пин SDA
#define I2C_SCL 22     // Пин SCL
#define I2C_TOUCH_FREQUENCY 400000  // Частота I2C (400kHz)
#define TOUCH_INT 39  // Пин прерывания (если требуется)
#define TOUCH_RST -1  // Пин сброса (или -1, если совпадает с TFT_RST)
// */
#define ILI9341_DRIVER

// Пины для TFT-дисплея
#define TFT_MISO  12
#define TFT_MOSI  13
#define TFT_SCLK  14
#define TFT_CS    15
#define TFT_DC     2
#define TFT_RST   -1   // Явный RESET
#define TFT_BL    27   // Подсветка (подтверждено, работает)

// Частоты SPI
#define SPI_FREQUENCY  20000000  // 20
// Подсветка
#define TFT_BACKLIGHT_ON HIGH
//шрифты опционально
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT
//сенсорит
#define TOUCH_CS -1  // Не используется, так как CST816S работает через I2C
#define CST816S_TOUCH  // Включить поддержку CST816S
#define I2C_SDA 33     // Пин SDA
#define I2C_SCL 32     // Пин SCL
#define I2C_TOUCH_FREQUENCY 400000  // Частота I2C (400kHz)
#define TOUCH_INT 22  // Пин прерывания (если требуется 21, 22)
#define TOUCH_RST 25  // Пин сброса (или -1, если совпадает с TFT_RST)